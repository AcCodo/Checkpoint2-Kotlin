package com.example.andrecodo_rm87145

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telecom.Call
import android.widget.Button
import com.example.andrecodo_rm87145.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var databind: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(Theme.currentTheme)
        databind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(databind.root)

        databind.btnSkills.setOnClickListener {
            val intent = Intent(this, Skills::class.java)
            startActivity(intent)
        }

        databind.btnTheme.setOnClickListener {

            Theme.switchTheme()
            recreate()
            databind.btnTheme.text = "@string/style_name_1"

        }
    }
}

object Theme {
    var currentTheme = R.style.Theme_AndreCodo_RM87145

    private const val ACTUAL = R.style.Theme_AndreCodo_RM87145
    private const val NEW = R.style.Theme_AndreCodo_RM87145_theme_2

    fun switchTheme() {
        Theme.currentTheme = when (Theme.currentTheme) {
            ACTUAL -> NEW
            NEW -> ACTUAL
            else -> -1
        }
    }
}