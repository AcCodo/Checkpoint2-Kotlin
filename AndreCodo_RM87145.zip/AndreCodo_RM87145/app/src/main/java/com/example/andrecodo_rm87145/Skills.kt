package com.example.andrecodo_rm87145

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Skills : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skills)
    }
}