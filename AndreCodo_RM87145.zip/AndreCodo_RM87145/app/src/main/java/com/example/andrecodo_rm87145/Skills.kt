package com.example.andrecodo_rm87145

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.andrecodo_rm87145.databinding.ActivitySkillsBinding

class Skills : AppCompatActivity() {

    private lateinit var databind: ActivitySkillsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(Theme.currentTheme)
        databind = ActivitySkillsBinding.inflate(layoutInflater)
        setContentView(databind.root)

        databind.button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}